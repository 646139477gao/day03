package cn.jiyun.mapper;

import java.util.List;

import org.apache.ibatis.annotations.Param;

import cn.jiyun.pojo.Link;

public interface LinkMapper {
	
	List<Link> findAll(Link li);
	
	void addLink(Link li);
	
	void editLink(Link li);
	
	void delLink(@Param("id") Integer id);
	
	Link findById(@Param("id") Integer id);
}
