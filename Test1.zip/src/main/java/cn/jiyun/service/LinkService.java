package cn.jiyun.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import cn.jiyun.mapper.LinkMapper;
import cn.jiyun.pojo.Link;

@Service
public class LinkService {
@Autowired
	LinkMapper linkMapper;
	public List<Link> findAll(Link li){
		return linkMapper.findAll(li);
	}

	public void addLink(Link li) {
		
		linkMapper.addLink(li);
	}

	public void editLink(Link li) {
		linkMapper.editLink(li);
	}

	public void delLink(Integer id) {
		linkMapper.delLink(id);
	}

	public Link findById(Integer id) {
		return linkMapper.findById(id);
	}
	
}
