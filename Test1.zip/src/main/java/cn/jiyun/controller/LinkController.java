package cn.jiyun.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import cn.jiyun.pojo.Link;
import cn.jiyun.service.LinkService;

@RestController
@RequestMapping("link")
public class LinkController {
	@Autowired
	LinkService linkService;
	@RequestMapping("findAll")
	public List<Link> findAll(@RequestBody Link li){
		return linkService.findAll(li);
	}
	@RequestMapping("addLink")
	public void addLink(@RequestBody Link li) {
		
		linkService.addLink(li);
	}
	@RequestMapping("editLink")
	public void editLink(@RequestBody Link li) {
		linkService.editLink(li);
	}
	@RequestMapping("delLink")
	public void delLink(Integer id) {
		linkService.delLink(id);
	}
	@RequestMapping("findById")
	public Link findById(Integer id) {
		return linkService.findById(id);
	}
}
